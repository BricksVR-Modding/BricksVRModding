﻿using MelonLoader;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


namespace DarkMode
{
    public static class BuildInfo
    {
        public const string Name = "Darkmode"; // Name of the Mod.  (MUST BE SET)
        public const string Description = "Mod for BricksVR, Makes the UI dark!"; // Description for the Mod.  (Set as null if none)
        public const string Author = "Dcybroz"; // Author of the Mod.  (MUST BE SET)
        public const string Company = "ManoVersa"; // Company that made the Mod.  (Set as null if none)
        public const string Version = "0.1.0"; // Version of the Mod.  (MUST BE SET)
        public const string DownloadLink = null; // Download Link for the Mod.  (Set as null if none)
    }

    public class DarkMode : MelonMod
    {
        public GameObject CreateButtonText;
        public GameObject titleText;
        public GameObject Welcome;
        public GameObject Joinsubtitle;
        public GameObject Version;
        public GameObject UserId;
        public GameObject UserIdClone; //Only to be used with Lucky2.0's FPS mod

        //Text GameObjects

        public GameObject CreateButton;
        public GameObject JoinButton;
        public GameObject SettingsButton;
        public GameObject SpaceBar;

        //Button GameObjects

        public GameObject background;
        public GameObject fpsbackground; //Only to be used with Lucky2.0's FPS mod
        public GameObject clonedBackground; //Only to be used with Lucky2.0's FPS mod

        //Orange 1f, 0.5f, 0f, 1f

        public override void OnApplicationStart() 
        {
            MelonLogger.Msg("Application started");
        }

        public override void OnApplicationLateStart() 
        {
            MelonLogger.Msg("Darkmode mod running!");
        }

        public override void OnSceneWasLoaded(int buildindex, string sceneName)
        {
            fpsbackground = GameObject.Find("Background");
            clonedBackground = GameObject.Instantiate(fpsbackground);

            MelonLogger.Msg("Full boot of mod and game, Success!");
            Image background = GameObject.Find("MenuBoard/Background").GetComponent<Image>();
            if (background == null)
                MelonLogger.Msg("Menuboard returned null");
            else
                MelonLogger.Msg("Background Found!");
            
            Color dark = background.color;
            dark = new Color(0.1332f, 0.1332f, 0.1332f, 1);
            background.color = dark;

            TMP_Text titleText = GameObject.Find("MenuBoard/Main/BricksVR Title").GetComponent<TMP_Text>();
            if (titleText == null)
                MelonLogger.Msg("Title neturned null");
            else
                MelonLogger.Msg("Title Found!");

            titleText.color = new Color(1f, 0.5f, 0f, 1f);

            TMP_Text Joinsubtitle = GameObject.Find("MenuBoard/Main/JoinSubtitle (1)").GetComponent<TMP_Text>();
            if (Joinsubtitle == null)
                MelonLogger.Msg("JoinSubtitle neturned null");
            else
                MelonLogger.Msg("Joinsubtitle Found!");

            Joinsubtitle.color = new Color(1f, 0.5f, 0f, 1f);

            Image CreateButton = GameObject.Find("MenuBoard/Main/CreateButton").GetComponent<Image>();
            if (Joinsubtitle == null)
                MelonLogger.Msg("CreateButton returned null");
            else
                MelonLogger.Msg("CreateButton Found!");

            CreateButton.color = new Color(1f, 0.5f, 0f, 1f);

            Image JoinButton = GameObject.Find("MenuBoard/Main/JoinButton").GetComponent<Image>();
            if (JoinButton == null)
                MelonLogger.Msg("JoinButton returned null");
            else
                MelonLogger.Msg("JoinButton Found!");

            JoinButton.color = new Color(1f, 0.5f, 0f, 1f);

            Image SettingsButton = GameObject.Find("MenuBoard/Main/SettingsButton").GetComponent<Image>();
            if (SettingsButton == null)
                MelonLogger.Msg("SettingsButton returned null");
            else
                MelonLogger.Msg("SettingsButton Found!");

            SettingsButton.color = new Color(1f, 0.5f, 0f, 1f);

            TMP_Text UserId = GameObject.Find("MenuBoard/UserID").GetComponent<TMP_Text>();

            UserId.color = new Color(1f, 0.5f, 0f, 1f);
        }

        public override void OnSceneWasInitialized(int buildindex, string sceneName) 
        {
            MelonLogger.Msg("Scene Running: " + buildindex.ToString() + " | " + sceneName);
        }

        public override void OnUpdate() 
        {

        }

        public override void OnFixedUpdate() 
        {
            
        }

        public override void OnLateUpdate() 
        {


            //TMP_Text UserIdClone = GameObject.Find("MenuBoard/UserID(Clone)").GetComponent<TMP_Text>();

            //UserIdClone.transform.position = new Vector3(1.7f, 92.64f, 3f);

            TMP_Text Version = GameObject.Find("MenuBoard/Version").GetComponent<TMP_Text>();

            Version.color = new Color(1f, 0.5f, 0f, 1f);

            Image SpaceBar = GameObject.Find("MenuBoard/Create/Keyboard/SpacebarRow/Spacebar").GetComponent<Image>();

            SpaceBar.color = new Color(1f, 0.5f, 0f, 1f);
        }

        public override void OnGUI() 
        {
            
        }

        public override void OnApplicationQuit() 
        {
            
        }

        public override void OnPreferencesSaved() 
        {
           
        }

        public override void OnPreferencesLoaded() 
        {
            
        }

        public override void BONEWORKS_OnLoadingScreen() 
        {
            // Used for BONEWORKS only
        }
    }
}