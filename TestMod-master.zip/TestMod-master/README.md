### GENERAL INFORMATION:

- An Example Mod for [MelonLoader](https://github.com/LavaGang/MelonLoader).

---

### LICENSING & CREDITS:

TestMod is licensed under the Apache License, Version 2.0. See [LICENSE](https://github.com/LavaGang/TestMod/blob/master/LICENSE.md) for the full License.